# Thesis Template

This repository is made for the capstone projects at HCMUT (Hochiminh City University of Technology).
The template can be used for project proposal as well as the dissertation. The main code for 
this template comes from [the initial project of Hung Vo](https://github.com/BKThesisTeam/thesis-template).

The template is based on regulations of HCMUT, therefore, it is subject to be changed over time.
Please make sure you are using the correct version.
